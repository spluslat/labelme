#!/bin/bash
APP_HOME=/home/hyina/anomalib
LOG_ROOT_DIR=/home/hyina/anomalib/logs
ITERATION=ite0001
CONFIG_NAME=custom2
CONFIG=${LOG_ROOT_DIR}/${ITERATION}/${CONFIG_NAME}.yaml
WEIGHTS=${LOG_ROOT_DIR}/${ITERATION}/${CONFIG_NAME}/fastflow/mvtec/run/weights/lightning/model.ckpt
INPUT=/mnt/c/workth/data/MVTec/custom/abnormal/000.png
OUTPUT=./${CONFIG_NAME}
# simple, full
VISUALIZATION_MODE=full

python3 ${APP_HOME}/tools/inference/lightning_inference.py \
    --config ${CONFIG}\
    --weights ${WEIGHTS}\
    --input ${INPUT} \
    --output ${OUTPUT} \
    --visualization_mode ${VISUALIZATION_MODE}
