#!/bin/bash
APP_HOME=/home/hyina/anomalib
# シェルスクリプトのディレクトリパスを取得
SHELL_DIR=$(cd "$(dirname "$0")" && pwd)
# 設定ファイル（半角スペース区切り）
CONFIG_PREFIXS=("custom2.yaml")
# 出力先
OUTPUT_ROOT_DIR=$SHELL_DIR/output
# フルパスを格納する配列
full_paths=()

# ファイルの存在をチェックし、フルパスを格納
for prefix in "${CONFIG_PREFIXS[@]}"; do
  file_path="$SHELL_DIR/$prefix"
  if [ -f "$file_path" ]; then
    full_paths+=("$file_path")
  fi
done

# フルパスの配列を表示
for path in "${full_paths[@]}"; do
  echo "$(date +"%Y-%m-%d %H:%M:%S") config:${path}"
  python3 ${APP_HOME}/tools/train.py --config ${path}
done
